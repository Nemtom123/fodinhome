-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2017. Okt 17. 07:20
-- Kiszolgáló verziója: 10.1.24-MariaDB
-- PHP verzió: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `fodinhome`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `beszallitok`
--

CREATE TABLE `beszallitok` (
  `beszallito_id` int(100) NOT NULL,
  `beszallito_nev` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `beszallito_ido` date NOT NULL,
  `beszallito_kod` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `beszallitok`
--

INSERT INTO `beszallitok` (`beszallito_id`, `beszallito_nev`, `beszallito_ido`, `beszallito_kod`) VALUES
(4, 'Pedo-Teo Bt', '2017-10-09', 199),
(5, 'Tuti-buli Kft', '2017-10-09', 99),
(7, 'Famacomp Kft', '2017-10-12', 112),
(8, 'Horgany Bt', '2017-10-12', 111),
(9, 'Gargantua Kft', '2017-10-12', 114),
(10, 'Ãlom Kft', '2017-10-12', 861),
(12, 'Mindaranda Bt', '2017-10-12', 1096632034),
(14, 'KÃ©k Kft', '2017-10-12', 608),
(22, 'Ã–ko szervezet Kft', '2017-10-12', 3040),
(23, 'Eres Kft', '2017-10-12', 3344),
(25, 'Fuga-buga Bt', '2017-10-12', 3952),
(27, 'Emberek Bt', '2017-10-12', 4560),
(29, 'Homokszem Bt', '2017-10-13', 391162904),
(30, 'Kikellene Kft', '2017-10-13', 622055684);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `categoria`
--

CREATE TABLE `categoria` (
  `blog_id` int(11) NOT NULL,
  `text` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `categoria`
--

INSERT INTO `categoria` (`blog_id`, `text`) VALUES
(1, 'Epitkezes'),
(2, 'Epites');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kiadas`
--

CREATE TABLE `kiadas` (
  `kiadas_id` int(10) NOT NULL,
  `termek_id` int(10) NOT NULL,
  `megrendelo_id` int(10) NOT NULL,
  `kiadasidate` date NOT NULL,
  `kiadasmertek` int(11) NOT NULL,
  `osszeg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `megnevezes`
--

CREATE TABLE `megnevezes` (
  `megnevezes_id` int(11) NOT NULL,
  `megnevezes` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `megnevezes`
--

INSERT INTO `megnevezes` (`megnevezes_id`, `megnevezes`) VALUES
(6, 'Ã–tÃ¶dik sor'),
(18, 'Csavar'),
(19, 'Vasipari termÃ©k'),
(20, 'Ã‰lek'),
(21, 'Elso elso'),
(22, 'Arany'),
(23, 'Ezust'),
(25, 'Ã‰kezetek ');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `megrendelo`
--

CREATE TABLE `megrendelo` (
  `megrendelo_id` int(10) NOT NULL,
  `megrendelocsaladi` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendelokereszt` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendelovaros` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendeloutca` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendelohazszam` varchar(10) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendeloemelet` varchar(10) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendeloemail` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendelotelefon` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendelomobil` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `megrendelodate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `megrendelo`
--

INSERT INTO `megrendelo` (`megrendelo_id`, `megrendelocsaladi`, `megrendelokereszt`, `megrendelovaros`, `megrendeloutca`, `megrendelohazszam`, `megrendeloemelet`, `megrendeloemail`, `megrendelotelefon`, `megrendelomobil`, `megrendelodate`) VALUES
(1, 'Mikorkafika', 'KÃ¡lmÃ¡n', 'Miskolc', 'KirÃ¡ly', '12', '2/4', 'mikorka.kalman@gmail.com', '0646745542', '06209673311', '2017-09-10'),
(2, 'Mikorbika', 'KÃ¡lmÃ¡nka', 'Miskolc', 'Kuruc', '12', '2/4', 'mik.kalman@gmail.com', '0646745542', '06209673311', '2017-09-10'),
(3, 'Fostos', 'Ferenc', 'Miskolc', 'KirÃ¡ly', '38', '2/1', 'fosferi@gmail.com', '46733312', '06209673311', '2017-09-10'),
(4, 'Fikusz', 'Kukisz', 'Miskolc', 'KirÃ¡lylÃ¡ny', '12', '2/4', 'fikuszkuki@gmail.com', '0646745542', '06209673311', '2017-09-10'),
(5, 'Merev', 'KlÃ¡ra', 'Miskolc', 'Szarkahegy', '34', '2/7', 'koraiklara@freemail.hu', '0646310310', '06304124121', '2017-09-10');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `posts`
--

CREATE TABLE `posts` (
  `posts_id` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_hungarian_ci NOT NULL,
  `kategori` int(11) NOT NULL,
  `date` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `body` longtext COLLATE utf8_hungarian_ci NOT NULL,
  `author` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `keywords` varchar(200) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `posts`
--

INSERT INTO `posts` (`posts_id`, `title`, `kategori`, `date`, `body`, `author`, `keywords`) VALUES
(1, 'Próba Verzió', 2, '2017.08.16', '  <p>Klasszikus Zeneszerzők.</p>\r\n                <ul>\r\n                    <li>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</li>\r\n                    <li>Donec id elit non mi porta gravida at eget metus.</li>\r\n                    <li>Nulla vitae elit libero, a pharetra augue.</li>\r\n                </ul>\r\n                <p>Donec ullamcorper nulla non metus auctor fringilla. Nulla vitae elit libero, a pharetra augue.</p>\r\n                <ol>\r\n                    <li>Vestibulum id ligula porta felis euismod semper.</li>\r\n                    <li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\r\n                    <li>Maecenas sed diam eget risus varius blandit sit amet non magna.</li>\r\n                </ol>\r\n                <p>Cras mattis consectetur purus sit amet fermentum. Sed posuere consectetur est at lobortis.</p>', 'Tommy', 'Építés'),
(2, '2 számú próba ', 1, '2017.08.16', '<p>Valami nagyon szar.</p>\r\n                <ul>\r\n                    <li>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</li>\r\n                    <li>Donec id elit non mi porta gravida at eget metus.</li>\r\n                    <li>Nulla vitae elit libero, a pharetra augue.</li>\r\n                </ul>\r\n                <p>Donec ullamcorper nulla non metus auctor fringilla. Nulla vitae elit libero, a pharetra augue.</p>\r\n                <ol>\r\n                    <li>Vestibulum id ligula porta felis euismod semper.</li>\r\n                    <li>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</li>\r\n                    <li>Maecenas sed diam eget risus varius blandit sit amet non magna.</li>\r\n                </ol>\r\n                <p>Cras mattis consectetur purus sit amet fermentum. Sed posuere consectetur est at lobortis.</p>', 'Géjza', 'Épitkezés');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `temektabla`
--

CREATE TABLE `temektabla` (
  `termek_id` int(10) NOT NULL,
  `termekneve` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `termek_megyseg` varchar(10) COLLATE utf8_hungarian_ci NOT NULL,
  `termek_ara_netto` int(100) NOT NULL,
  `termek_ujnetto` int(10) NOT NULL,
  `termek_date` date NOT NULL,
  `termek_mennyiseg` int(10) NOT NULL,
  `uj_termek_mennyiseg` int(10) NOT NULL,
  `megnevezes_id` int(10) NOT NULL,
  `osssznetto` int(20) NOT NULL,
  `osszbrutto` int(11) NOT NULL,
  `tbrutto` int(11) NOT NULL,
  `novekedes` int(11) NOT NULL,
  `csokkenes` int(11) NOT NULL,
  `ujossznetto` int(10) NOT NULL,
  `ujosszbrutto` int(10) NOT NULL,
  `ujtbrutto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `temektabla`
--

INSERT INTO `temektabla` (`termek_id`, `termekneve`, `termek_megyseg`, `termek_ara_netto`, `termek_ujnetto`, `termek_date`, `termek_mennyiseg`, `uj_termek_mennyiseg`, `megnevezes_id`, `osssznetto`, `osszbrutto`, `tbrutto`, `novekedes`, `csokkenes`, `ujossznetto`, `ujosszbrutto`, `ujtbrutto`) VALUES
(1, 'TÃ©gla', 'Db', 100, 0, '2017-09-13', 0, 0, 20, 0, 0, 127, 0, 6, 0, 0, 0),
(2, 'FÃºrÃ³szÃ¡r', 'Darab', 1459, 0, '2017-09-10', -20, 0, 22, -30639, -38912, 0, 0, 1, 0, 0, 0),
(3, 'EmelÅ‘ke', 'Db', 5640, 0, '2017-09-11', 2, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 'GyilokkÃ©s', 'db', 12345, 0, '0000-00-00', 10, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 'EmelÅ‘', '', 0, 0, '0000-00-00', 0, 0, 18, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 'EkÃ©kfÃ©kek', 'Db', 23, 0, '2017-09-14', 100, 0, 22, 2208, 2805, 29, 1, 99, 0, 0, 29),
(7, 'furÃ³szÃ¡r', 'Db', 1450, 0, '2017-09-12', -9, 0, 20, -13050, -16574, 1842, 10, 19, 0, 0, 0),
(8, '12*12 facsavar', '', 0, 0, '0000-00-00', 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 'rÃ©szeg', '', 0, 0, '0000-00-00', 0, 0, 18, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 'rÃ©szegek', 'Db', 123, 0, '2017-09-12', -12, 0, 21, -1476, -1875, 156, 12, 3, 0, 0, 0),
(11, 'rÃ©szegecskÃ©k', 'Db', 123, 0, '2017-09-12', 0, 0, 22, 0, 1, 156, 12, 6, 0, 0, 0),
(12, 'Laposvas', '', 0, 0, '0000-00-00', 0, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0),
(13, 'Fika', 'db', 0, 0, '0000-00-00', 0, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 'Eke', '', 0, 0, '0000-00-00', 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 'Ecset', 'Db', 12345, 0, '2017-09-13', -1, 0, 22, -24690, -31356, 15678, 1, 1, 0, 0, 15678),
(16, 'Lap', '', 0, 0, '0000-00-00', 0, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0),
(17, 'Ãcs ceruza', 'Db', 78, 0, '0000-00-00', -1, 0, 19, -296, -423, 270, 1, 1, 0, 0, 270),
(18, 'LÃ©tra 200 cm', '', 0, 0, '0000-00-00', 0, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0),
(19, 'Ã‰lvÃ©dÅ‘ alluminium', '', 0, 0, '0000-00-00', 0, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0),
(20, 'SzÃ¶gvas', '', 0, 0, '0000-00-00', 0, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0),
(21, 'Nagyvas', '', 0, 0, '0000-00-00', 0, 0, 18, 0, 0, 0, 0, 0, 0, 0, 0),
(22, 'FÃ©szer', '', 0, 0, '0000-00-00', 0, 0, 25, 0, 0, 0, 0, 0, 0, 0, 0),
(23, 'KolbÃ¡sz', '', 0, 0, '0000-00-00', 0, 0, 18, 0, 0, 0, 0, 0, 0, 0, 0),
(24, 'Ã‰kszerek', '', 0, 0, '0000-00-00', 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `termekkiadas`
--

CREATE TABLE `termekkiadas` (
  `kiadas_id` int(100) NOT NULL,
  `termek_id` int(100) NOT NULL,
  `mennyiseg` int(100) NOT NULL,
  `megrendelo_id` int(100) NOT NULL,
  `kiadasi_ido` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `termekkiadas`
--

INSERT INTO `termekkiadas` (`kiadas_id`, `termek_id`, `mennyiseg`, `megrendelo_id`, `kiadasi_ido`) VALUES
(1, 1, 10, 4, '2017-10-15'),
(2, 10, 1, 4, '2017-10-15'),
(3, 1, 1, 4, '2017-10-15'),
(4, 10, 1, 4, '2017-10-15'),
(5, 1, 1, 4, '2017-10-15'),
(6, 10, 1, 4, '2017-10-15'),
(7, 1, 1, 4, '2017-10-15'),
(8, 17, 1, 4, '2017-10-15'),
(9, 15, 1, 3, '2017-10-15'),
(10, 7, 1, 5, '2017-10-15'),
(11, 7, 10, 5, '2017-10-15'),
(12, 7, 10, 4, '2017-10-15'),
(13, 17, 1, 4, '2017-10-15');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_email` varchar(40) COLLATE utf8_hungarian_ci NOT NULL,
  `joining_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jog` int(2) NOT NULL,
  `user_pass` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `user_name` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `joining_date`, `jog`, `user_pass`, `user_name`) VALUES
(3, 'dobiasz.tamas@gmail.com', '2017-08-21 05:05:48', 0, '$2y$10$39no4Bf/NmfmyxeDEkDpp.wDytBjSfUmUNLF4B.r1Jsdays.qCm9y', 'Tomika');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `beszallitok`
--
ALTER TABLE `beszallitok`
  ADD PRIMARY KEY (`beszallito_id`);

--
-- A tábla indexei `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`blog_id`);

--
-- A tábla indexei `kiadas`
--
ALTER TABLE `kiadas`
  ADD PRIMARY KEY (`kiadas_id`);

--
-- A tábla indexei `megnevezes`
--
ALTER TABLE `megnevezes`
  ADD PRIMARY KEY (`megnevezes_id`);

--
-- A tábla indexei `megrendelo`
--
ALTER TABLE `megrendelo`
  ADD PRIMARY KEY (`megrendelo_id`);

--
-- A tábla indexei `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`posts_id`);

--
-- A tábla indexei `temektabla`
--
ALTER TABLE `temektabla`
  ADD PRIMARY KEY (`termek_id`);

--
-- A tábla indexei `termekkiadas`
--
ALTER TABLE `termekkiadas`
  ADD PRIMARY KEY (`kiadas_id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `beszallitok`
--
ALTER TABLE `beszallitok`
  MODIFY `beszallito_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT a táblához `categoria`
--
ALTER TABLE `categoria`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT a táblához `kiadas`
--
ALTER TABLE `kiadas`
  MODIFY `kiadas_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT a táblához `megnevezes`
--
ALTER TABLE `megnevezes`
  MODIFY `megnevezes_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT a táblához `megrendelo`
--
ALTER TABLE `megrendelo`
  MODIFY `megrendelo_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT a táblához `posts`
--
ALTER TABLE `posts`
  MODIFY `posts_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT a táblához `temektabla`
--
ALTER TABLE `temektabla`
  MODIFY `termek_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT a táblához `termekkiadas`
--
ALTER TABLE `termekkiadas`
  MODIFY `kiadas_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
